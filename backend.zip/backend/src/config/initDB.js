const db = require("./db");

async function initializeDatabase() {
    try {
        await db.query(`
            CREATE TABLE IF NOT EXISTS projects (
                id INT AUTO_INCREMENT PRIMARY KEY,

                user_id INT NOT NULL,

                title VARCHAR(255) NOT NULL,

                description TEXT NULL,

                status VARCHAR(50) NOT NULL DEFAULT 'Waiting',

                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

                input_image VARCHAR(500) NULL,

                geometric_image VARCHAR(500) NULL,

                curve_image VARCHAR(500) NULL,

                shading_image VARCHAR(500) NULL,

                colouring_image VARCHAR(500) NULL,

                CONSTRAINT fk_projects_user
                    FOREIGN KEY (user_id)
                    REFERENCES users(id)
                    ON DELETE CASCADE
            )
        `);

        console.log("✅ Users table is ready.");

        await db.query(`
            CREATE TABLE IF NOT EXISTS projects (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                title VARCHAR(255) NOT NULL,
                description TEXT,
                status VARCHAR(50) DEFAULT 'Pending',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    ON UPDATE CURRENT_TIMESTAMP,

                CONSTRAINT fk_projects_user
                    FOREIGN KEY (user_id)
                    REFERENCES users(id)
                    ON DELETE CASCADE
            )
        `);

        console.log("✅ Projects table is ready.");
    } catch (error) {
        console.error("❌ Database initialization failed:", error.message);
        throw error;
    }
}

module.exports = initializeDatabase;